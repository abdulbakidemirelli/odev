﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace App6
{
    [Activity(Label = "Details")]
    public class Details : Activity
    { 
         
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.details);
            TextView ticket = FindViewById<TextView>(Resource.Id.tid);
            TextView userid = FindViewById<TextView>(Resource.Id.uid);
            TextView hescode = FindViewById<TextView>(Resource.Id.hcode);
            TextView username = FindViewById<TextView>(Resource.Id.uname);
            TextView ticketid = FindViewById<TextView>(Resource.Id.ticketid);
            ticket.Text = "Ticket\nDetails";
            var uid = Intent.Extras.GetString("id");
            var hcode = Intent.Extras.GetString("hescode");
            var uname = Intent.Extras.GetString("name");
            userid.Text = uid;
            hescode.Text = hcode;
            username.Text = uname;
            Random rn = new Random(); 
            ticketid.Text = rn.Next(100000000, 999999999).ToString();
        }
    }
}