﻿using Android.App;
using Android.OS;
using Android.Support.V7.App;
using Android.Runtime;
using Android.Widget;
using Android.Content;

namespace App6
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.activity_main);
            Button btn = FindViewById<Button>(Resource.Id.btn);
            TextView ticket = FindViewById<TextView>(Resource.Id.tid);
            EditText userid = FindViewById<EditText>(Resource.Id.uid);
            EditText hescode = FindViewById<EditText>(Resource.Id.hcode);
            ticket.Text = "Ticket\nCheck";
            btn.Click += delegate {
                if (userid.Text == "baki" && hescode.Text == "123")
                {
                    Toast.MakeText(this, "Kayıt oldu", ToastLength.Short).Show();
                    var detay = new Intent(this, typeof(Details));
                    detay.PutExtra("id", userid.Text);
                    detay.PutExtra("hescode", hescode.Text);
                    detay.PutExtra("name", "demirelli");
                    StartActivity(detay);
                }
                else
                {
                    Toast.MakeText(this,"No Ticket Found",ToastLength.Short).Show();
                    StartActivity(typeof(Register));
                }
            };
        }
    }
}